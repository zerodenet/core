from pathlib import Path
import gzip,hashlib,json,re,shutil
raw=Path('/workspace/core-baseline-artifacts');stage=Path('/workspace/core-next/icmp-native47-and50-archive');assert not stage.exists();(stage/'evidence').mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
records=[]
paths=set(raw.glob('pr05-parallel-47-icmp*'))|set(raw.glob('pr05-parallel-50-icmp*'))
paths|={Path('/workspace/core-next')/name for name in ('run-icmp-native47.py','run-icmp-native50.py','run-icmp-provider-native50.py','icmp-native-47-environment-review.md','archive-icmp-native50.py','verify-frozen-archive.py')}
for p in sorted(paths):
 b=p.read_bytes();z=gzip.compress(b,mtime=0);rel='evidence/'+p.name+'.gz';(stage/rel).write_bytes(z)
 records.append(dict(source=str(p),path=rel,raw_bytes=len(b),raw_sha256=sha(b),gzip_bytes=len(z),gzip_sha256=sha(z)))
identities=[]
for name in ('pr05-parallel-47-icmp-native-container.json','pr05-parallel-50-icmp-native-container.json','pr05-parallel-50-icmp-provider-container.json'):
 d=json.loads((raw/name).read_text());binary=Path(d['binary']);assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==d['binary_sha256']
 for c in d['commands']:
  b=Path(c['log']).read_bytes();assert sha(b)==c['log_sha256']
  c['counts']=[list(map(int,row)) for row in re.findall(r'^test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',b.decode(),re.M)]
 identities.append(d)
manifest=dict(overall_passed=False,scope='Actual ICMP Linux native selected library/provider/legacy cases only; original failures retained; no ALL17 proof',records=records,rounds=identities,field_label_correction='Root50 raw runner accidentally renamed historical original47_permission_failures_preserved to original50; separate correction JSON retains rawsha and exact actual command data unchanged.')
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(stage/'preparation').mkdir();shutil.copy2('/workspace/core-next/verify-frozen-archive.py',stage/'preparation/verify-frozen-archive.py')
(stage/'README.md').write_text('''# ICMP native selected evidence\n\nOriginal root47 task-process native run failed all ten cases before acquisition (RAW EPERM1, datagram EACCES13); those logs remain in the frozen42–48 archive. Its unchanged immutable executable then ran in a network-none container: eight of nine normal cases passed, the real cooperative-wake getter assertion failed, and the separate RAW-denial/datagram fallback case passed.\n\nRoot50 `61f01a2b260adae5228950391b1859bdcd99f037` retains all old assertions and corrects the test executor to exercise a real zero-budget synchronous native wake. All nine normal cases plus the separate fallback passed. Platform executable SHA `2942083b2b52d7deb640fffcf8175cf4e9d24ac0d3494530b2d7bea6efcc114f`. Its four explicitly ignored HostIcmpProbeOwner native cases passed, and the original IPv4/IPv6 legacy echo case passed separately. These scope-specific results do not certify a complete RuntimeHost, resource replacement, other platforms or ALL17.\n\nImage is fixed by digest, network none, read-only binary/root filesystem, one CPU/1GiB; normal default capabilities and the separate fallback capability-drop/group settings are recorded exactly. No host configuration was changed. Environment Python socket probes are readiness checks, not owner close receipts. The Windows check is separate compile-only evidence. No fake native disposition was inferred from descriptor Drop, task exit or address rebinding.\n\nAll command argv/exit/raw logs, source HEAD/tree/lock and immutable executable hashes are retained. Executables remain outside Git as immutable local artifacts; the archive records and rehashes their identities. The raw root50 manifest has a historical metadata-key naming error; its separate label-correction JSON identifies the exact raw digest and intended root47 reference without altering original command evidence.\n''')
for r in records:
 z=(stage/r['path']).read_bytes();b=gzip.decompress(z);assert sha(z)==r['gzip_sha256'] and sha(b)==r['raw_sha256'] and Path(r['source']).read_bytes()==b
print(json.dumps({'stage':str(stage),'records':len(records),'manifest_sha256':sha((stage/'manifest.json').read_bytes()),'all17_passed':False}))
