# ICMP native47 environment and provider review

Prepared read-only on 2026-10-20. No Cargo, native tests, Docker containers,
system configuration changes or permission requests were performed by this
review. The existing ten native failures remain failures, not skips or passes.

## Exact existing artifact

The root47 manifest `/workspace/core-baseline-artifacts/pr05-parallel-focused-47.json`
records source `ad409401874e52794fbaf2a9ff21a5fa4a6dff34`, tree
`63b306dc49b07fe81a4a875e8c51b46e139a9a58`, source lock SHA256
`ffed93de069ad338a786490fc65e5cbc01dfc6a2c9116ab7ba853bc5abbc8764`.
Its log records `/workspace/core-target/debug/deps/zero_platform_tokio-28be1d99d4286d76`.
The still-existing executable was observed with SHA256
`260f2a0fbd733aa99e5e041ba9be1044b1aefb28382c0d7bf86da8c464061b59`,
size 15058752, mtime 2026-10-20 10:43:06.342199400 UTC, GNU build ID
`db1ff902225cda9bbed6e6edc310bb7cc8263e2a`.
Root48 builds a different executable `zero_platform_tokio-92926e671dc40c68`;
do not relabel that new artifact as root47. Root should verify the SHA immediately
before any run and retain an immutable copy if cache cleanup may remove it.

Host `ldd` resolves only libgcc_s.so.1, libm.so.6, libc.so.6 and the ELF loader
`/lib64/ld-linux-x86-64.so.2`; no libssl or other external protocol runtime is
required by this executable. Actual container loader compatibility is still a
preflight, not established merely by host ldd.

## Exact environment blocker

The current execution process has UID/GID 1000, no supplementary groups,
CapInh/Prm/Eff/Bnd/Amb all zero, NoNewPrivs=1, Seccomp=2. Existing
`/proc/sys/net/ipv4/ping_group_range` is `65534 65534`. These facts explain why
this process cannot acquire RAW ICMP and why its group cannot acquire ping
DGRAM sockets; actual log47 returns RAW EPERM(1), DGRAM EACCES(13),
KnownNoNative. Seccomp may impose further restrictions, so errno alone is not
proof of its exact filter rule. No post-create/readiness/close/panic assertion
was reached for these cases. No native close receipt can be inferred.

Docker daemon read-only discovery succeeds (Engine28.4.0, default runc,
security options seccomp/cgroupns, no rootless/userns option reported). No
containers were running at discovery. Existing image is exactly
`python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1`
(local image ID `sha256:df18428df8a0f9189c84e7424d214b4c50092af1f9dca5842a00c41c39bda316`).
It has empty Config.User (default root). This permits a proposed isolated
container test entry; discovery alone does not prove its actual capabilities,
ping range, loopback or ICMP permission.

## Root-only minimal commands (not executed here)

Keep the existing immutable image, no pull, network none, loopback only,
read-only rootfs and read-only binary mount. No host networking, privileged
mode, added capabilities, sysctls or host user/capability changes. The standard
Docker capability set is used for the nine ordinary native tests. The exact
fallback test is run separately with NET_RAW removed and group65534 added,
satisfying the current allowed ping group if the container range is identical.
Thus all ten existing cases remain required, with their original assertions.

```bash
icmp47_bin=/workspace/core-target/debug/deps/zero_platform_tokio-28be1d99d4286d76
icmp47_sha=260f2a0fbd733aa99e5e041ba9be1044b1aefb28382c0d7bf86da8c464061b59
icmp47_image=python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1
[[ $(sha256sum "$icmp47_bin" | cut -d' ' -f1) == "$icmp47_sha" ]] || exit 1
icmp47_args=(--rm --pull=never --network=none --read-only --cpus=1
  --memory=1073741824 --memory-swap=1073741824
  --mount "type=bind,src=$icmp47_bin,dst=/icmp-tests,readonly")
```

Loader/list preflight (no Rust test execution):

```bash
docker run "${icmp47_args[@]}" "$icmp47_image" /bin/sh -c \
  'ldd /icmp-tests && /icmp-tests --list'
```

Environmental preflight, run with standard args and then with
`--cap-drop=NET_RAW --group-add=65534` before the image. This creates/closes only
four actual ICMP probe descriptors and performs no send or configuration change;
its result is environment readiness only, never a Rust owner close witness.

```bash
docker run -i "${icmp47_args[@]}" "$icmp47_image" python3 - <<'PY'
import json, os, pathlib, socket
fields = ('CapEff:', 'CapBnd:', 'NoNewPrivs:', 'Seccomp:')
print(json.dumps({'uid':os.getuid(), 'gid':os.getgid(), 'groups':os.getgroups(),
 'ping_group_range':pathlib.Path('/proc/sys/net/ipv4/ping_group_range').read_text().strip(),
 'security':[s for s in pathlib.Path('/proc/self/status').read_text().splitlines()
             if s.startswith(fields)]}))
for family, proto in ((socket.AF_INET,socket.IPPROTO_ICMP),
                       (socket.AF_INET6,socket.IPPROTO_ICMPV6)):
 for kind in (socket.SOCK_RAW,socket.SOCK_DGRAM):
  try:
   fd=socket.socket(family,kind,proto)
   fd.close()
   print(json.dumps({'family':int(family),'kind':int(kind),'created':True}))
  except OSError as error:
   print(json.dumps({'family':int(family),'kind':int(kind),'created':False,
                     'errno':error.errno,'error':str(error)}))
PY
```

Nine ordinary real native tests; preserve the complete stdout/stderr and exit:

```bash
docker run "${icmp47_args[@]}" "$icmp47_image" /icmp-tests \
  controlled_icmp::tests --ignored --test-threads=1 --nocapture \
  --skip controlled_icmp::tests::echo::actual_raw_permission_denial_falls_back_to_real_icmp_datagram
```

The tenth case, preserving its exact real denial/fallback/echo/receipt checks:

```bash
docker run "${icmp47_args[@]}" --cap-drop=NET_RAW --group-add=65534 \
  "$icmp47_image" /icmp-tests --exact \
  controlled_icmp::tests::echo::actual_raw_permission_denial_falls_back_to_real_icmp_datagram \
  --ignored --test-threads=1 --nocapture
```

If these existing container settings cannot create native ICMP, retain actual
errno/security/uid/groups/range and report that environment blocked. Do not
change the host ping range, add privileged mode, broaden the tests or claim
post-create paths qualified. A successful preflight does not imply Rust tests
passed; their actual payload/close assertions and exit remain required.

## Provider implementation review (feb481b6 +989b8ac3)

- `resources/icmp.rs::new` is pure, has one exact actual instance, only accepts
  canonical NativeIcmp, and constructs one same ControlledIcmpOwner. Grant is
  Weak with exact generation; there is no ResourceAccess escape or second map.
- `grant.rs::bind` checks same live instance and cancellation both before and
  inside the short state gate. Contention is an explicit NotSubmitted/Capacity
  result with no FD touched; it is not evidence that the max socket count was
  reached. Caller handling of this transient result must be reviewed during
  rawIP integration; it is not permission to silently claim a successful probe.
- Platform acquisition installs a reservation then Unknown sentinel before
  native create; native success installs that same original before checks.
  Only actual RAW create PermissionDenied enables one DGRAM fallback. No later
  failure is hidden by fallback. Registration consumes the original under an
  Unknown sentinel; Err/unwind cannot release the slot or reconstruct a FD.
- Grant close remains allowed after revoke, but same pool+entry identity is
  checked by the platform. Wrong-pool/old-view cannot close a replacement.
  Unknown remains charged; Unix close errors including EINTR are not retried.
  Windows retry requires its retained explicit known-open source contract.
- Parent cancellation is issued outside the provider state mutex. Native
  close/poll relay callbacks can reenter grant and get a nonblocking busy result
  rather than recursively block the provider mutex. No task or queue is added.
- `physical_confirmed` refreshes the actual pool even after a poisoned mutex;
  it requires canceled admission and no actual live/Unknown entries. Cached
  no-acquisition status cannot survive a post-create unwind as proof.
- State counters consume actual platform receipts once. Unknown shutdown Err
  leaves earlier close counts for take_closed_io; first ownership fault Arc is
  retained independently. Neither an empty extracted report nor fault()==None
  alone is physical proof (both may be busy observations). Registry task/user
  obligations remain additional, independent requirements.
- Ordinary known-disposition per-probe acquisition errors are returned to the
  caller with the actual final OS error object; the pool also retains bounded
  first acquisition/raw-permission sources. They are not automatically whole
  generation ownership faults. Unknown and native-close faults are sticky.

No new concrete unsafe-disposition or false-close path was found in this
read-only pass. Actual native provider tests are still required; root47 did
not compile/run this provider and its environment failures cannot qualify it.
Root48 and subsequent binaries must retain their own source/lock/SHA labels.
