from pathlib import Path
import hashlib,json,subprocess,time,shutil
root=Path('/workspace/core-baseline-artifacts')
source=Path('/workspace/core-target/debug/deps/zero_platform_tokio-92926e671dc40c68')
expected='2942083b2b52d7deb640fffcf8175cf4e9d24ac0d3494530b2d7bea6efcc114f'
assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
binary=root/'zero-platform-root50-icmp-proof'
assert not binary.exists()
shutil.copy2(source,binary)
image='python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1'
base=['docker','run','--rm','--pull=never','--network=none','--read-only','--cpus=1','--memory=1073741824','--memory-swap=1073741824','--mount',f'type=bind,src={binary},dst=/icmp-tests,readonly']
probe="""import os,pathlib,socket,json
print(json.dumps({'uid':os.getuid(),'gid':os.getgid(),'groups':os.getgroups(),'range':pathlib.Path('/proc/sys/net/ipv4/ping_group_range').read_text(),'security':[x for x in pathlib.Path('/proc/self/status').read_text().splitlines() if x.startswith(('CapEff:','CapBnd:','NoNewPrivs:','Seccomp:'))]}))
for f,p in ((socket.AF_INET,socket.IPPROTO_ICMP),(socket.AF_INET6,socket.IPPROTO_ICMPV6)):
 for t in (socket.SOCK_RAW,socket.SOCK_DGRAM):
  try:
   s=socket.socket(f,t,p);s.close();print(json.dumps({'family':int(f),'kind':int(t),'created':True}))
  except OSError as e:print(json.dumps({'family':int(f),'kind':int(t),'created':False,'errno':e.errno,'error':str(e)}))
"""
normal='core-icmp50-normal'
fallback='core-icmp50-fallback'
cases=[('loader',base+[image,'/bin/sh','-c','ldd /icmp-tests && /icmp-tests --list'],30),('environment-normal',base+[image,'python3','-c',probe],30),('environment-fallback',base+['--cap-drop=NET_RAW','--group-add=65534',image,'python3','-c',probe],30),('normal',base+['--name',normal,image,'/icmp-tests','controlled_icmp::tests','--ignored','--test-threads=1','--nocapture','--skip','controlled_icmp::tests::echo::actual_raw_permission_denial_falls_back_to_real_icmp_datagram'],90),('fallback',base+['--name',fallback,'--cap-drop=NET_RAW','--group-add=65534',image,'/icmp-tests','--exact','controlled_icmp::tests::echo::actual_raw_permission_denial_falls_back_to_real_icmp_datagram','--ignored','--test-threads=1','--nocapture'],30)]
rows=[]
manifest=root/'pr05-parallel-50-icmp-native-container.json'
assert not manifest.exists()
for name,argv,timeout in cases:
 log=root/f'pr05-parallel-50-icmp-container-{name}.txt';assert not log.exists()
 start=time.monotonic()
 with log.open('w') as stream:
  try:
   p=subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
   code=p.returncode
  except subprocess.TimeoutExpired:
   code='timeout'
   subprocess.run(['docker','rm','-f',normal if name=='normal' else fallback],stdout=stream,stderr=subprocess.STDOUT)
 row=dict(name=name,argv=argv,exit=code,seconds=time.monotonic()-start,log=str(log),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 rows.append(row)
 manifest.write_text(json.dumps(dict(source_head='61f01a2b260adae5228950391b1859bdcd99f037',tree='d5a9d27162da5ff807f90cec0fe194bb8d5cce2a',lock_sha256='cbfa65b5969b78787ea35dfbaae93e44953103d4fd89bdcb8425f2ee9b780cdb',binary=str(binary),binary_sha256=expected,image=image,network='none',host_configuration_changed=False,original50_permission_failures_preserved=True,commands=rows),indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if code and name=='loader':break
assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected
