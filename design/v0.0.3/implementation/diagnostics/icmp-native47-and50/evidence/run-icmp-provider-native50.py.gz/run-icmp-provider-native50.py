from pathlib import Path
import hashlib,json,re,subprocess,time,shutil
root=Path('/workspace/core-baseline-artifacts')
m=json.loads((root/'pr05-parallel-focused-50.json').read_text())
row=next(r for r in m['commands'] if r['name']=='proxy-library');assert row['exit']==0
source=Path(re.search(r'Running unittests .*?\((/workspace/core-target/[^)]+)\)',Path(row['log']).read_text()).group(1))
hashfile=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
expected=hashfile(source)
binary=root/'zero-proxy-root50-icmp-provider-proof';assert not binary.exists();shutil.copy2(source,binary);assert hashfile(binary)==expected
image='python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1'
base=['docker','run','--rm','--pull=never','--network=none','--read-only','--cpus=1','--memory=1073741824','--memory-swap=1073741824','--env','RUST_MIN_STACK=16777216','--mount',f'type=bind,src={binary},dst=/icmp-provider-tests,readonly']
cases=[('loader',base+[image,'/bin/sh','-c','ldd /icmp-provider-tests && /icmp-provider-tests --list'],30),('provider',base+['--name','core-icmp50-provider',image,'/icmp-provider-tests','component::instance::resources::icmp::tests::native::','--ignored','--test-threads=1','--nocapture'],90),('legacy-echo',base+['--name','core-icmp50-legacy-echo',image,'/icmp-provider-tests','--exact','runtime::inbound_operation::raw_ip::icmp::tests::direct_icmp_echo_probe_returns_real_ipv4_and_ipv6_loopback_replies','--ignored','--test-threads=1','--nocapture'],30)]
rows=[];manifest=root/'pr05-parallel-50-icmp-provider-container.json';assert not manifest.exists()
for name,argv,timeout in cases:
 log=root/f'pr05-parallel-50-icmp-provider-{name}.txt';assert not log.exists();start=time.monotonic()
 with log.open('w') as output:
  try:code=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:
   code='timeout';subprocess.run(['docker','rm','-f','core-icmp50-provider' if name=='provider' else 'core-icmp50-legacy-echo'],stdout=output,stderr=subprocess.STDOUT)
 result=dict(name=name,argv=argv,exit=code,seconds=time.monotonic()-start,log=str(log),log_sha256=hashfile(log))
 rows.append(result)
 manifest.write_text(json.dumps(dict(source_head=m['head'],tree=m['tree'],lock_sha256=m['lock_sha256'],binary=str(binary),binary_sha256=expected,image=image,network='none',host_configuration_changed=False,platform_native47_failures_preserved=True,commands=rows),indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='argv'}),flush=True)
 if code and name=='loader':break
assert hashfile(binary)==expected
