import pathlib,subprocess,time,json
root=pathlib.Path('/workspace/core-baseline-artifacts')
rows=[]
for index in range(20):
 started=time.monotonic()
 try:
  p=subprocess.run([str(root/'browser-tokio154-synchronized'),'--test-threads=16','--nocapture'],capture_output=True,text=True,timeout=20)
  row=dict(index=index,exit=p.returncode,seconds=time.monotonic()-started)
  (root/f'browser-tokio154-synchronized-suite-{index}.txt').write_text(p.stdout+p.stderr)
 except subprocess.TimeoutExpired as e:
  row=dict(index=index,exit='timeout',seconds=time.monotonic()-started)
  (root/f'browser-tokio154-synchronized-suite-{index}.txt').write_bytes((e.stdout or b'')+(e.stderr or b''))
 rows.append(row)
 print(json.dumps(row),flush=True)
 if row['exit']!=0:break
print(json.dumps(dict(trials=len(rows),failures=sum(x['exit']!=0 for x in rows),cpu_max=pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),memory_max=pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip())),flush=True)
