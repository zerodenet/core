"""Replay the recorded immutable kernel-process experiment with a fresh prefix.

The original five rounds were orchestrated inline; their exact argv is retained
in pr04-kernel-echo-ipc-constrained.json. This is an equivalent standalone replay.
"""
import argparse
import hashlib
import json
import pathlib
import re
import subprocess
import tempfile
import time

parser = argparse.ArgumentParser()
parser.add_argument('--prefix', required=True)
args = parser.parse_args()
root = pathlib.Path('/workspace/core-baseline-artifacts')
original = json.loads((root / 'pr04-kernel-echo-constrained.json').read_text())
expected = {
    root / 'pr04-kernel-echo-kernel-process': original['test_binary_sha256'],
    root / 'pr04-kernel-echo-zero': original['core_binary_sha256'],
}
assert all(hashlib.sha256(path.read_bytes()).hexdigest() == digest for path, digest in expected.items())
assert '/' not in args.prefix
assert not any(root.glob(args.prefix + '*')), 'use a new output prefix'
records = []
for trial in range(1, 6):
    path = root / f'{args.prefix}-{trial}.txt'
    argv = original['argv'].copy()
    with tempfile.TemporaryDirectory(prefix='core-kernel-echo-ipc-', dir='/tmp') as scratch:
        index = argv.index(str(root / 'pr04-kernel-echo-zero') + ':/workspace/core-target/debug/zero:ro') - 1
        argv[index:index] = ['-v', scratch + ':/workspace/core-target/debug:rw']
        started = time.monotonic()
        with path.open('x') as output:
            result = subprocess.run(argv, stdout=output, stderr=subprocess.STDOUT)
        rows = re.findall(r'test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;', path.read_text())
        row = dict(trial=trial, exit=result.returncode, seconds=time.monotonic() - started,
                   argv=argv, log=path.name, counts=[sum(int(r[i]) for r in rows) for i in range(3)])
    records.append(row)
    assert all(hashlib.sha256(path.read_bytes()).hexdigest() == digest for path, digest in expected.items())
    (root / (args.prefix + '.json')).write_text(json.dumps(dict(records=records, hashes={str(k): v for k, v in expected.items()}), indent=2) + '\n')
    print(json.dumps({key: value for key, value in row.items() if key != 'argv'}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
