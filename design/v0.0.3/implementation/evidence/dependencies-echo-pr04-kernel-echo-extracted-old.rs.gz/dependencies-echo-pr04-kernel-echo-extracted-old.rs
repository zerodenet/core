use std::net::TcpListener;

pub struct EchoListener {
    port: u16,
}
impl EchoListener {
    pub fn bind_avoiding(excluded: &[u16]) -> Self {
        let mut port = super::free_port();
        while excluded.contains(&port) {
            port = super::free_port();
        }
        Self { port }
    }
    pub fn port(&self) -> u16 {
        self.port
    }
    pub fn into_listener(self) -> TcpListener {
        TcpListener::bind(("127.0.0.1", self.port)).expect("bind echo")
    }
}
