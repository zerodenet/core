import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import time

root = pathlib.Path('/workspace/core-baseline-artifacts')
log = root / 'pr03-dependency-bindings-final2-test.txt'
text = log.read_text()
qualification = json.loads((root / 'pr03-dependency-bindings-final2-validation.json').read_text())
assert any(row['name'] == 'test' and row['exit'] == 0 for row in qualification['commands'])
source = pathlib.Path(re.search(r'Running unittests.*?\(([^)]+/zero_proxy-[^)]+)\)', text).group(1))
binary = root / 'pr03-dependency-bindings-proxy-tests-2'
assert not binary.exists()
shutil.copy2(source, binary)
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
image = 'python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1'
probe = '''import json,pathlib,subprocess,sys
p=pathlib.Path('/sys/fs/cgroup')
limits={n:(p/n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']}
assert limits == {'cpu.max':'100000 100000','memory.max':'1073741824','memory.swap.max':'0'}, limits
print(json.dumps({'limits':limits}),flush=True)
sys.exit(subprocess.run(['/test-proxy','component::','--nocapture']).returncode)
'''
argv = ['docker','run','--rm','--cpus=1','--memory=1g','--memory-swap=1g',
        '--network=none','--user=1000:1000','--mount',
        f'type=bind,source={binary},target=/test-proxy,readonly', image,
        'python','-c',probe]
output = root / 'pr03-dependency-bindings-constrained-2.txt'
assert not output.exists()
started = time.monotonic()
with output.open('w') as stream:
    result = subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT)
rows = re.findall(r'test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;', output.read_text())
manifest = dict(source_qualification=dict(head=qualification['head'], tree=qualification['tree'], test_log=str(log)), binary=str(binary),binary_sha256=digest,source_binary=str(source),
                argv=argv,exit=result.returncode,seconds=time.monotonic()-started,
                counts=[sum(int(row[i]) for row in rows) for i in range(3)],
                log=str(output),scope='Same immutable 50-test component filter from the frozen dependency-bindings whole-workspace proxy binary; actual typed dependency-instance bindings, factory preflight validation and rebuilt consumer lifecycle. Not full workspace or RS01/physical device qualification.')
path = root / 'pr03-dependency-bindings-constrained-2.json'
assert not path.exists()
path.write_text(json.dumps(manifest,indent=2)+'\n')
assert hashlib.sha256(binary.read_bytes()).hexdigest() == digest
print(json.dumps(manifest),flush=True)
raise SystemExit(result.returncode)
