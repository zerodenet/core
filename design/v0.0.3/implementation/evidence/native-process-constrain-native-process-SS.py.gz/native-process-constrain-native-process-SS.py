import hashlib,json,pathlib,re,shutil,subprocess,time

root=pathlib.Path('/workspace/core-baseline-artifacts')
text=(root/'pr03-native-process-SS-library-1.txt').read_text()
assert re.search(r'^test result: ok\. 36 passed; 0 failed;',text,re.M)
source=pathlib.Path(re.search(r'Running unittests.*?\(([^)]+)\)',text).group(1))
binary=root/'pr03-native-process-SS-tests'
assert not binary.exists()
shutil.copy2(source,binary)
digest=hashlib.sha256(binary.read_bytes()).hexdigest()
image='python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1'
probe='''import json,pathlib,subprocess,sys
p=pathlib.Path('/sys/fs/cgroup')
limits={n:(p/n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']}
assert limits=={'cpu.max':'100000 100000','memory.max':'1073741824','memory.swap.max':'0'},limits
print(json.dumps(limits),flush=True)
sys.exit(subprocess.run(['/test-ss','--nocapture']).returncode)
'''
argv=['docker','run','--rm','--cpus=1','--memory=1g','--memory-swap=1g','--network=none','--user=1000:1000','--mount',f'type=bind,source={binary},target=/test-ss,readonly',image,'python','-c',probe]
manifest=dict(binary=str(binary),binary_sha256=digest,source_binary=str(source),records=[],source_precommit=str(root/'pr03-native-process-precommit-validation.json'),scope='Same immutable complete36-test native-process SS library, actual child spawning/PIDs/reaping; five rounds in separate network namespaces, readonly binary,1CPU1GiB/no swap/user1000. Original budgets/assertions retained. Not whole workspace or RS01.')
out=root/'pr03-native-process-SS-constrained.json'
assert not out.exists()
for trial in range(1,6):
    log=root/f'pr03-native-process-SS-constrained-{trial}.txt'
    assert not log.exists()
    started=time.monotonic()
    with log.open('w') as stream:
        result=subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT)
    rows=re.findall(r'^test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(),re.M)
    record=dict(trial=trial,argv=argv,exit=result.returncode,seconds=time.monotonic()-started,log=str(log),counts=[sum(int(r[i]) for r in rows) for i in range(3)])
    manifest['records'].append(record);out.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(record),flush=True)
    if result.returncode or record['counts']!=[36,0,0]:raise SystemExit(1)
assert hashlib.sha256(binary.read_bytes()).hexdigest()==digest
