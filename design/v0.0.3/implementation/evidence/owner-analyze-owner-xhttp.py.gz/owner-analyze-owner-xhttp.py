import base64, collections, hashlib, json, pathlib, re

root=pathlib.Path('/workspace/core-baseline-artifacts')
manifest=json.loads((root/'pr03-owner-xhttp-trace.json').read_text())
rows=[]
for trial in manifest['trials']:
    for port in ['30002','30018']:
        directory=root/f"pr03-owner-xhttp-{trial['index']}"/'tap'/port
        if not directory.exists(): continue
        groups=collections.defaultdict(list)
        for path in directory.glob('*-up.bin'):
            for match in re.finditer(rb'PUT ([^\r\n]+) HTTP/1\.1\r\n(.*?)\r\n\r\n',path.read_bytes(),re.S):
                headers={k.lower():v.strip() for item in match[2].split(b'\r\n') if b':' in item for k,v in [item.split(b':',1)]}
                if b'x-session' not in headers or b'cookie' not in headers: continue
                seq=re.search(rb'x_seq=(\d+)',headers[b'cookie'])
                parts=sorted((int(k[7:]),v) for k,v in headers.items() if k.startswith(b'x-data-'))
                if not seq or not parts: continue
                encoded=b''.join(v for _,v in parts)
                data=base64.urlsafe_b64decode(encoded+b'='*((-len(encoded))%4))
                groups[headers[b'x-session'].decode()].append((int(seq[1]),data))
        for sid,parts in sorted(groups.items()):
            parts.sort(key=lambda item:item[0]); data=b''.join(v for _,v in parts)
            sequence=[s for s,_ in parts]
            row=dict(trial=trial['index'],port=port,session=sid,posts=len(parts),decoded_bytes=len(data),
                     command=data[18],contiguous_sequences=sequence==list(range(len(parts))),
                     sha256=hashlib.sha256(data).hexdigest())
            if row['command']==1:
                row['expected_bytes']=131099;row['payload_values']=sorted(set(data[26:]))
                row['expected_uniform_payload']=len(row['payload_values'])==1 and row['payload_values'][0] in range(4)
            elif row['command']==3: row['expected_bytes']=1643
            rows.append(row)
summary=dict(source_commit=manifest['source_commit'],source_tree=manifest['source_tree'],
             binary_sha256=manifest['binary_sha256'],reference_sha256=manifest['reference_sha256'],
             trials=len(manifest['trials']),failures=sum(r['exit']!=0 for r in manifest['trials']),
             decoded_sessions=len(rows),tcp_sessions=sum(r['command']==1 for r in rows),
             mux_udp_sessions=sum(r['command']==3 for r in rows),
             mismatches=[r for r in rows if not r['contiguous_sequences'] or r['decoded_bytes']!=r.get('expected_bytes') or r.get('expected_uniform_payload') is False],
             limit='Integrity decoding covers the first header/cookie metadata case for both current-thread and 4-worker runtimes. Passing diagnostics do not resolve or erase the previous remote early-EOF failure; no identical root-cause claim.',sessions=rows)
(root/'pr03-owner-xhttp-wire-analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='sessions'}),flush=True)
