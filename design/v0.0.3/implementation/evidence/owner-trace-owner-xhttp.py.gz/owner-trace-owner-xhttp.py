import hashlib,json,os,pathlib,shutil,subprocess,time
root=pathlib.Path('/workspace/core-baseline-artifacts')
source=pathlib.Path('/workspace/core-target/debug/deps/vless_xhttp_options-a233bd373bf61bf0')
manifest=json.loads((root/'pr03-owner-final-validation.json').read_text())
assert any(row['name']=='test' and row['exit']==0 and row['head_unchanged'] and row['source_clean'] for row in manifest['commands'])
executable=root/'pr03-owner-xhttp-options';assert not executable.exists();shutil.copy2(source,executable)
image='python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1'
meta=dict(source_commit=manifest['head'],source_tree=manifest['tree'],binary_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),reference_sha256=hashlib.sha256(pathlib.Path('/workspace/core-tools/xray-reference/xray').read_bytes()).hexdigest(),image=image,scope='Only extended metadata test, unchanged assertions/deadlines; original frozen binary and pinned reference. Each trial read-only workspace with dedicated writable artifact directory and network namespace/1CPU1GiB/no swap/user1000.',trials=[])
for index in range(20):
 name=f'core-owner-xhttp-{os.getpid()}-{index}'
 trial=root/f'pr03-owner-xhttp-{index}';trial.mkdir(exist_ok=False)
 tap=trial/'tap';tap.mkdir()
 command=['docker','run','--rm','--name',name,'--cpus=1','--memory=1g','--memory-swap=1g','--network=none','--user=1000:1000','-e','XRAY_BIN=/workspace/core-tools/xray-reference/xray','-e','RUST_MIN_STACK=16777216','-e','RUST_LOG=zero_proxy=debug,zero_transport::split_http=trace','-e',f'XHTTP_TAP_DIR={tap}','-v','/workspace:/workspace:ro','-v',f'{trial}:{trial}','-w','/workspace/core',image,str(executable),'xhttp_extended_metadata_payload_padding_interoperate_both_directions','--ignored','--exact','--nocapture']
 start=time.monotonic()
 try:
  with (trial/'output.txt').open('w') as log: result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=85)
  row=dict(index=index,exit=result.returncode,elapsed=time.monotonic()-start,log=str(trial/'output.txt'))
 except subprocess.TimeoutExpired:
  row=dict(index=index,exit='process_timeout',elapsed=time.monotonic()-start,log=str(trial/'output.txt'))
 finally:
  subprocess.run(['docker','rm','--force',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 meta['trials'].append(row);(root/'pr03-owner-xhttp-trace.json').write_text(json.dumps(meta,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if row['exit']!=0:break
