import concurrent.futures
import json
import pathlib
import subprocess
import time

root = pathlib.Path('/workspace/core-baseline-artifacts')
executable = (root / 'pr03-hysteria-executable.txt').read_text().strip()
target = 'hysteria::tests::authentication_gates_native_streams_and_negotiates_bandwidth'

def trial(index):
    started = time.monotonic()
    try:
        result = subprocess.run([executable, '--exact', target, '--nocapture'],
                                capture_output=True, text=True, timeout=15)
        return dict(index=index, elapsed=time.monotonic()-started,
                    exit=result.returncode, output=result.stdout+result.stderr)
    except subprocess.TimeoutExpired as error:
        return dict(index=index, elapsed=time.monotonic()-started, exit='process_timeout',
                    output=str(error))

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    with (root / 'pr03-hysteria-stress.jsonl').open('w') as output:
        failures = 0
        for row in pool.map(trial, range(200)):
            output.write(json.dumps(row)+'\n'); output.flush()
            if row['exit'] != 0:
                failures += 1
                print(json.dumps(row), flush=True)
        print(json.dumps(dict(trials=200, failures=failures,
                              cpu_max=pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),
                              memory_max=pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip())), flush=True)
        raise SystemExit(bool(failures))
