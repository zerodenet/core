module core-xray-ownership-probe

go 1.26.0

require github.com/xtls/xray-core v1.260327.0

require google.golang.org/protobuf v1.36.11 // indirect
