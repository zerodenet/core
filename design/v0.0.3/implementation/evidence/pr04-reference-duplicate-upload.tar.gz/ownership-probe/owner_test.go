package probe

import (
    "bytes"
    "os"
    "testing"

    "github.com/xtls/xray-core/common/buf"
    "github.com/xtls/xray-core/transport/pipe"
)

// Model the legal interleaving after Xray's pipe has signalled its reader:
// the consumer copies/releases transferred buffers before Write counts them.
// The gate makes ownership order deterministic and avoids a Go data race.
type gatedWriter struct {
    writer *pipe.Writer
    released <-chan struct{}
}
func (w gatedWriter) WriteMultiBuffer(mb buf.MultiBuffer) error {
    if err := w.writer.WriteMultiBuffer(mb); err != nil { return err }
    <-w.released
    return nil
}

func TestTransferredUploadMustReportTheAcceptedByteCount(t *testing.T) {
    payload := bytes.Repeat([]byte{9}, 1643)
    reader, writer := pipe.New()
    released := make(chan struct{})
    received := make(chan []byte, 1)
    go func() {
        mb, err := reader.ReadMultiBuffer()
        if err != nil { panic(err) }
        data := make([]byte, mb.Len())
        mb.Copy(data)
        buf.ReleaseMulti(mb)
        received <- data
        close(released)
    }()
    container := buf.MultiBufferContainer{}
    if _, err := container.Write(payload); err != nil { t.Fatal(err) }
    handoff := gatedWriter{writer, released}
    reported := 0
    for _, buffer := range container.MultiBuffer {
        // This optional snapshot is the only ablation variable. The fixed
        // reference reads buffer.Len() after this ownership transfer instead.
        before := int(buffer.Len())
        if err := handoff.WriteMultiBuffer(buf.MultiBuffer{buffer}); err != nil { t.Fatal(err) }
        if os.Getenv("PROBE_SNAPSHOT") == "1" { reported += before } else { reported += int(buffer.Len()) }
    }
    data := <-received
    if !bytes.Equal(data, payload) { t.Fatal("actual upstream pipe changed payload") }
    t.Logf("actual upstream pipe accepted=%d; upload writer reported=%d; snapshot=%s", len(data), reported, os.Getenv("PROBE_SNAPSHOT"))
    if reported != len(payload) { t.Fatalf("io.Writer byte-count violation: delivered %d but returned (%d, nil)",len(data),reported) }
}
