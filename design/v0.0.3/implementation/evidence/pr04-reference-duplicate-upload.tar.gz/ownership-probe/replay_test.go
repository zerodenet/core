package probe

import (
    "bytes"
    "os"
    "testing"

    "github.com/xtls/xray-core/common/buf"
    "github.com/xtls/xray-core/transport/pipe"
)

type uploadByteCounter struct { deliveries [][]byte; snapshot bool }

func (w *uploadByteCounter) Write(payload []byte) (int,error) {
    reader, writer := pipe.New()
    buffer := buf.New()
    if _,err:=buffer.Write(payload);err!=nil{return 0,err}
    before:=int(buffer.Len())
    allowRelease,released:=make(chan struct{}),make(chan struct{})
    received:=make(chan []byte,1)
    go func(){
        mb,err:=reader.ReadMultiBuffer();if err!=nil{panic(err)}
        copy:=make([]byte,mb.Len());mb.Copy(copy);received<-copy
        <-allowRelease
        buf.ReleaseMulti(mb);close(released)
    }()
    if err:=writer.WriteMultiBuffer(buf.MultiBuffer{buffer});err!=nil{return 0,err}
    data:=<-received
    // First transfer: consumer finishes before the writer reads Len. Second
    // transfer: the writer reads Len before release. Both are valid schedules.
    first:=len(w.deliveries)==0
    if first { close(allowRelease);<-released }
    reported:=int(buffer.Len())
    if w.snapshot { reported=before }
    if !first { close(allowRelease);<-released }
    w.deliveries=append(w.deliveries,data)
    return reported,nil
}

func TestActualUpstreamWriteAllBytesReplaysOnTheInvalidZeroCount(t *testing.T){
    payload:=bytes.Repeat([]byte{9},1643)
    writer:=&uploadByteCounter{snapshot:os.Getenv("PROBE_SNAPSHOT")=="1"}
    if err:=buf.WriteAllBytes(writer,payload,nil);err!=nil{t.Fatal(err)}
    expected:=2;if writer.snapshot { expected=1 }
    if len(writer.deliveries)!=expected{t.Fatalf("submissions=%d, expected=%d",len(writer.deliveries),expected)}
    for _,data:=range writer.deliveries{if !bytes.Equal(data,payload){t.Fatal("replayed bytes differ")}}
    t.Logf("actual upstream WriteAllBytes completed with %d identical submissions; snapshot=%v",len(writer.deliveries),writer.snapshot)
}
