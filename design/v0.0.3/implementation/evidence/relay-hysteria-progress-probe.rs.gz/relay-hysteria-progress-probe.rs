use zero_transport::hysteria::{Profile, OptionsRef, Client, accept_connection};
use std::sync::Arc;
use tokio::{io::{AsyncReadExt, AsyncWriteExt}, time::{timeout, Duration}};
fn selected_transport(profile: &Profile, server: bool) -> quinn::TransportConfig {
 let mut transport=profile.transport(server).unwrap();
 if let Ok(value)=std::env::var("PROBE_MIN_PACKETS") {
  transport.congestion_controller_factory(Arc::new(zero_transport::quic::negotiated::Factory{
   adaptive: Arc::new(zero_transport::quic::bbr::BbrConfig::default()),
   disable_loss_compensation: false,
   minimum_packets: value.parse().unwrap(),
  }));
 }
 transport
}
fn endpoint_with_profile(profile: Profile) -> (quinn::Endpoint, Profile) {
    let cert = rcgen::generate_simple_self_signed(vec!["localhost".into()]).unwrap();
    let mut tls = rustls::ServerConfig::builder_with_provider(Arc::new(
        rustls::crypto::ring::default_provider(),
    ))
    .with_protocol_versions(&[&rustls::version::TLS13])
    .unwrap()
    .with_no_client_auth()
    .with_single_cert(
        vec![cert.cert.der().clone()],
        rustls::pki_types::PrivatePkcs8KeyDer::from(cert.signing_key.serialize_der()).into(),
    )
    .unwrap();
    tls.alpn_protocols = vec![b"h3".to_vec()];
    let mut config = quinn::ServerConfig::with_crypto(Arc::new(
        quinn::crypto::rustls::QuicServerConfig::try_from(tls).unwrap(),
    ));
    config.transport_config(Arc::new(selected_transport(&profile, true)));
    (
        quinn::Endpoint::server(config, "127.0.0.1:0".parse().unwrap()).unwrap(),
        profile,
    )
}
async fn dial(address: std::net::SocketAddr, profile: &Profile) -> quinn::Connection {
    let mut config = zero_transport::quic::client_config(true, None, &[b"h3".to_vec()], None).unwrap();
    config.transport_config(Arc::new(selected_transport(profile, false)));
    let mut endpoint = quinn::Endpoint::client("127.0.0.1:0".parse().unwrap()).unwrap();
    endpoint.set_default_client_config(config);
    endpoint
        .connect(address, "localhost")
        .unwrap()
        .await
        .unwrap()
}
#[tokio::main(flavor="current_thread")]
async fn main(){
 tracing_subscriber::fmt().with_env_filter("quinn_proto=trace,quinn=debug,zero_transport=trace").with_ansi(false).init();
    timeout(Duration::from_secs(10), async {
        // A small bandwidth-delay product deterministically reaches the
        // minimum window, including on a loaded loopback runner.
        let profile = Profile::from_options(OptionsRef {
            auth: "secret",
            uplink_bytes_per_sec: 1_000,
            downlink_bytes_per_sec: 1_000,
            ..Default::default()
        })
        .unwrap();
        let (endpoint, server_profile) = endpoint_with_profile(profile.clone());
        let address = endpoint.local_addr().unwrap();
        let server = tokio::spawn(async move {
            let connection = endpoint.accept().await.unwrap().await.unwrap();
            let incoming = accept_connection(connection.clone(), &server_profile);
            let mut stream = incoming.accept().await.unwrap();
            let mut ping = [0; 4];
            stream.read_exact(&mut ping).await.unwrap();
            assert_eq!(&ping, b"ping");
            println!(
                "server window={} mtu={} rtt={:?}",
                connection.congestion_state().window(),
                connection.stats().path.current_mtu,
                connection.rtt()
            );
            stream.write_all(b"pong").await.unwrap();
            stream.shutdown().await.unwrap();
            connection.closed().await;
        });
        let connection = dial(address, &profile).await;
        let client = Client::authenticate(connection, &profile).await.unwrap();
        let mut stream = client.open().await.unwrap();
        stream.write_all(b"ping").await.unwrap();
        let mut body = Vec::new();
        stream.read_to_end(&mut body).await.unwrap();
        assert_eq!(body, b"pong");
        drop(stream);
        drop(client);
        server.await.unwrap();
    })
    .await
    .expect("small BDP must not strand response or FIN within the original 10s deadline");
}
