import json
import pathlib
import subprocess
import time

binary='/evidence/pr04-hysteria-both-transport'
cpu=pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip()
memory=pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip()
print(json.dumps(dict(cpu_max=cpu,memory_max=memory)),flush=True)
assert cpu == '100000 100000' and memory == '1073741824'
targets=[
 'hysteria::tests::authentication_gates_native_streams_and_negotiates_bandwidth',
 'hysteria::tests::progress::negotiated_small_bandwidth_keeps_response_and_fin_sendable_below_one_packet_bdp',
]
failures=0
for index in range(20):
 for target in targets:
  started=time.monotonic()
  try:
   result=subprocess.run([binary,'--exact',target,'--nocapture'],capture_output=True,text=True,timeout=15)
   row=dict(index=index,target=target,exit=result.returncode,seconds=time.monotonic()-started,output=result.stdout+result.stderr)
  except subprocess.TimeoutExpired as error:
   row=dict(index=index,target=target,exit='process_timeout',seconds=time.monotonic()-started,output=str(error))
  failures+=row['exit']!=0
  print(json.dumps(row),flush=True)
print(json.dumps(dict(trials=40,failures=failures)),flush=True)
raise SystemExit(bool(failures))
