import hashlib
import json
import pathlib
import subprocess
import time

repo = pathlib.Path('/workspace/core')
artifacts = pathlib.Path('/workspace/core-baseline-artifacts')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()

head = git('rev-parse', 'HEAD')
tree = git('rev-parse', 'HEAD^{tree}')
if git('status', '--porcelain'):
    raise SystemExit('refusing qualification of a dirty/untracked source tree')
manifest = dict(head=head, tree=tree,
                lock_sha256=hashlib.sha256((repo/'Cargo.lock').read_bytes()).hexdigest(),
                commands=[])
commands = [
    ('fmt', ['cargo', 'fmt', '--all', '--check']),
        ('check', ['cargo', 'check', '--locked', '--workspace']),
    ('test', ['bash', 'scripts/test-workspace.sh']),
        ('release', ['cargo', 'build', '--locked', '--release']),
    ('no-std', ['cargo', 'check', '--locked', '--target', 'thumbv7em-none-eabi',
                '-p', 'zero-traits', '-p', 'zero-core']),
    ('minimal', ['cargo', 'check', '--locked', '-p', 'zero-proxy', '--no-default-features']),
    ('dependencies', ['python3', 'scripts/check-runtime-contracts.py']),
]
for name, argv in commands:
    path = artifacts/f'pr03-shared-preparation-final-{name}.txt'
    if path.exists():
        raise SystemExit(f'refusing to overwrite evidence: {path}')
    started = time.monotonic()
    with path.open('w') as output:
        result = subprocess.run(argv, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
    row = dict(name=name, argv=argv, exit=result.returncode,
               seconds=time.monotonic()-started, log=str(path),
               head_unchanged=git('rev-parse', 'HEAD') == head,
               source_clean=not git('status', '--porcelain'),
               lock_unchanged=hashlib.sha256((repo/'Cargo.lock').read_bytes()).hexdigest() == manifest['lock_sha256'])
    manifest['commands'].append(row)
    (artifacts/'pr03-shared-preparation-final-validation.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    if row['exit'] or not row['head_unchanged'] or not row['source_clean'] or not row['lock_unchanged']:
        raise SystemExit(1)
