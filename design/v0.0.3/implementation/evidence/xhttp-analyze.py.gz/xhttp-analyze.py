import pathlib,re,json,collections
root=pathlib.Path('/workspace/core-baseline-artifacts/pr04-xhttp-tap')
log=re.sub(r'\x1b\[[0-9;]*m','',pathlib.Path('/workspace/core-baseline-artifacts/pr04-xhttp-trace.txt').read_text())
dispatch=collections.defaultdict(list)
for line in log.splitlines():
    m=re.search(r'XHTTP request dispatch session=([\w-]+) sequence=Some\((\d+)\)',line)
    if m:dispatch[m[1]].append(int(m[2]))
sessions=collections.defaultdict(list)
for path in root.glob('*/*-up.bin'):
    data=path.read_bytes()
    for match in re.finditer(rb'(?:PUT|GET|POST|PATCH) [^\r\n]+ HTTP/1\.1\r\n(.*?)\r\n\r\n',data,re.S):
        h=match[1]
        sid=re.search(rb'(?im)^x-session: *([\w-]+)',h)
        seq=re.search(rb'(?im)^cookie:.*?\bx_seq=(\d+)',h)
        if sid and seq:sessions[sid[1].decode()].append((int(seq[1]),path.name,path.parent.name,match.start(),match.end()))
rows=[]
for sid,items in sessions.items():
    wire=sorted({x[0] for x in items});seen=sorted(set(dispatch[sid]));maximum=max(wire)
    row=dict(session=sid,wire_count=len(wire),wire_range=[min(wire),maximum],wire_missing=[i for i in range(maximum+1) if i not in wire],dispatched_count=len(seen),dispatched_missing=[i for i in wire if i not in seen],last_dispatched=seen[-15:],files=sorted({x[1] for x in items}),root=items[0][2])
    rows.append(row)
pathlib.Path('/workspace/core-baseline-artifacts/pr04-xhttp-wire-analysis.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
