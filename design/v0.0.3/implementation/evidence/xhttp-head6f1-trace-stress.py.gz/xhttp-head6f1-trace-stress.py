import concurrent.futures,hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/core-baseline-artifacts')
executable=str(root/'pr04-head6f1-xhttp-options')
image='python@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1'
def trial(index):
    name=f'core-xhttp-trace6f1-{os.getpid()}-{index}'
    tap=root/f'pr04-head6f1-trace-tap-{index}';tap.mkdir(exist_ok=True)
    started=time.monotonic()
    command=['docker','run','--rm','--name',name,'--cpus=1','--memory=1g','--memory-swap=1g','--network=none','--user=1000:1000','-e','XRAY_BIN=/workspace/core-tools/xray-reference/xray','-e','RUST_MIN_STACK=16777216','-e','RUST_LOG=zero_proxy=debug,zero_transport::split_http=trace','-e',f'XHTTP_TAP_DIR={tap}','-v','/workspace:/workspace','-w','/workspace/core',image,executable,'--ignored','--test-threads=4','--nocapture']
    try:
        p=subprocess.run(command,capture_output=True,text=True,timeout=85)
        row=dict(index=index,elapsed=time.monotonic()-started,exit=p.returncode,output=p.stdout+p.stderr)
    except subprocess.TimeoutExpired as e:
        row=dict(index=index,elapsed=time.monotonic()-started,exit='process_timeout',output=str(e))
    finally:
        subprocess.run(['docker','rm','--force',name],capture_output=True)
    (root/f'pr04-head6f1-trace-{index}.txt').write_text(row.pop('output'))
    return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    failures=0
    with (root/'pr04-head6f1-trace.jsonl').open('w') as out:
        for row in pool.map(trial,range(40)):
            out.write(json.dumps(row)+'\n');out.flush()
            if row['exit']!=0: failures+=1;print(json.dumps(row),flush=True)
    print(json.dumps(dict(trials=40,failures=failures,binary_sha256=hashlib.sha256(pathlib.Path(executable).read_bytes()).hexdigest(),isolation='each trial separate network namespace /1CPU1GiB/no swap/user1000/networknone',note='Prior shared-namespace 2-process harness invalid due per-process fixed port ranges; retained but excluded.')),flush=True)
    raise SystemExit(bool(failures))
